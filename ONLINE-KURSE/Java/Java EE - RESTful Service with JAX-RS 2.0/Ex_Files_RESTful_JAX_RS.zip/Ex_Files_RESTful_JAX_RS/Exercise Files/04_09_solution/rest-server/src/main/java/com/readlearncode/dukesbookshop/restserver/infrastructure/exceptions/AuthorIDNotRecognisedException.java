package com.readlearncode.dukesbookshop.restserver.infrastructure.exceptions;

/**
 * Source code github.com/readlearncode
 *
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
public class AuthorIDNotRecognisedException extends Exception {
}