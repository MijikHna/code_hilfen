package com.readlearncode.dukesbookshop.restserver.rest;

import javax.ejb.Stateless;
import javax.ws.rs.Path;

/**
 * @author Alex Theedom www.readlearncode.com
 * @version 1.0
 */
@Stateless
@Path("/books")
public class BookResource {
}
