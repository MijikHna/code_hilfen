This is a demonstration repository for Git Intermediate Techniques.
