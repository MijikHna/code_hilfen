This is a demonstraton repository for Git Intermediate Techniques.

